import 'package:flutter/material.dart';
import 'package:poke_dex/poke_dex_app.dart';

void main() {
  runApp(const PokeDexApp());
}



